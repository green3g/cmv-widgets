define ({
    root: {
        labels: {
            startEditing: 'Start editing',
            stopEditing: 'Stop editing'
        }
    }
});