define ({
    root: {
        title: 'Toggle search bar',
        labels: {
            address: 'Address',
            neighborhood: 'Neighborhood',
            city: 'City',
            subregion: 'Subregion',
            region: 'Region',
            postalCode: 'Postal code',
            countryCode: 'Country code',
            locatorName: 'Locator name',
            getAddressHere: 'Get address here'
        }
    }
});