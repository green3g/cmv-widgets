define ({
    root: {
        labels: {
            selectLayer: 'Choose "All Visible Layers" or a single layer for identify:',
            allVisibleLayers: '*** All Visible Layers ***'
        },
        rightClickMenuItem: {
            label: 'Identify here'
        },
        mapInfoWindow: {
            identifyingTitle: 'Identifying...'
        }
    }
});