define ({
    root: {
        title: 'Basemaps'
    }
});