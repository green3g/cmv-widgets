define ({
    root: {
        labels: {
            point: 'Point',
            circle: 'Circle',
            polyline: 'Polyline',
            freehandPolyline: 'Freehand polyline',
            polygon: 'Polygon',
            freehandPolygon: 'Freehand polygon',
            stopDrawing: 'Stop drawing',
            clearDrawing: 'Clear drawing',
            currentDrawMode: 'Current draw mode:',
            currentDrawModeNone: 'None'
        }
    }
});