define({
	map: true,
	editable: true,
	bookmarks: [
		{
			extent: {
				xmin: -15489130.48708616,
				ymin: 398794.4860580916,
				xmax: -5891085.7193757,
				ymax: 8509680.431452557,
				spatialReference: {
					wkid: 102100
				}
			},
			name: 'USA'
		}
	]
});