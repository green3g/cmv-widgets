define([
    'dojo/_base/lang',
    'dijit/layout/AccordionContainer',
    'dijit/layout/ContentPane',
    'dojo/dom-construct',
    'gis/CMV_Widgets/widgets/RelationshipTable/RelationshipTable'
], function (lang, Container, ContentPane, domConstruct, RelationshipTable) {
    var formatters = {
        attributeList: function (identifyInfo) {
            var listItem = '<li>{0}: {1}</li>';
            var html = ['<ul>'];
            for (var a in identifyInfo.attributes) {
                //make sure a is an own property
                if (identifyInfo.attributes.hasOwnProperty(a)) {
                    html.push(lang.replace(listItem, [a, identifyInfo.attributes[a]]));
                }
            }
            html.push('</ul>');
            return html.join('');
        },
        /**
         * a function factory for popup that returns a function which creates a tab container with two tabs
         * @param {type} relationshipInfo - the parameters for the RelationshipTable
         * @returns {Function}
         */
        relationshipTable: function (relationshipInfo) {
            return function (identifyInfo) {
                console.log(identifyInfo)
                //from https://developers.arcgis.com/javascript/jssamples/widget_infowindowchart.html
                var container = new Container({
                    style: 'height: 100%; width: 100%;',
                    onShow: function () {
                        this.inherited(arguments);
                        console.log(this)
                        this.resize();
                    }
                }, domConstruct.create('div'));
                container.addChild(new ContentPane({
                    title: 'Attributes',
                    content: formatters.attributeList(identifyInfo)
                }));
                container.addChild(new RelationshipTable(lang.mixin({
                    attributes: identifyInfo.attributes
                }, relationshipInfo)));
                return container.domNode;

            };
        }
    };
    return {
        map: true,
        mapClickMode: true,
        mapRightClickMenu: true,
        identifyLayerInfos: true,
        identifyTolerance: 5,
        // config object definition:
        //	{<layer id>:{
        //		<sub layer number>:{
        //			<pop-up definition, see link below>
        //			}
        //		},
        //	<layer id>:{
        //		<sub layer number>:{
        //			<pop-up definition, see link below>
        //			}
        //		}
        //	}

        // for details on pop-up definition see: https://developers.arcgis.com/javascript/jshelp/intro_popuptemplate.html

        identifies: {
            meetupHometowns: {
                0: {
                    title: 'Hometowns',
                    content: formatters.relationshipTable({
                        url: 'http://sampleserver3.arcgisonline.com/ArcGIS/rest/services/Petroleum/KSPetro/MapServer/0',
                        relationshipId: 3,
                        objectIdField: 'OBJECTID',
                        title: 'Inspections',
                        columns: [{
                                field: 'API_NUMBER',
                                label: 'Api Number',
                                formatter: function (num) {
                                    return '#' + num;
                                }
                            }, {
                                field: 'LATITUDE',
                                label: 'Latitude (y)'
                            }, {
                                field: 'LONGITUDE',
                                label: 'Longitude (x)'
                            }]
                    })
                }
            },
            louisvillePubSafety: {
                2: {
                    title: 'Police Station',
                    fieldInfos: [{
                            fieldName: 'Name',
                            visible: true
                        }, {
                            fieldName: 'Address',
                            visible: true
                        }, {
                            fieldName: 'Type',
                            visible: true
                        }, {
                            fieldName: 'Police Function',
                            visible: true
                        }, {
                            fieldName: 'Last Update Date',
                            visible: true
                        }]
                },
                8: {
                    title: 'Traffic Camera',
                    description: '{Description} lasted updated: {Last Update Date}',
                    mediaInfos: [{
                            title: '',
                            caption: '',
                            type: 'image',
                            value: {
                                sourceURL: '{Location URL}',
                                linkURL: '{Location URL}'
                            }
                        }]
                }
            }
        }

    };
});