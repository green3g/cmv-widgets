define([
    'esri/units',
    'esri/geometry/Extent',
    'esri/config',
    'esri/tasks/GeometryService',
    'esri/layers/ImageParameters'
], function (units, Extent, esriConfig, GeometryService, ImageParameters) {

    // url to your proxy page, must be on same machine hosting you app. See proxy folder for readme.
    esriConfig.defaults.io.proxyUrl = '/~gregg/cmv-app/viewer/proxy/PHP/proxy.php';
    esriConfig.defaults.io.alwaysUseProxy = false;
    // url to your geometry server.
    esriConfig.defaults.geometryService = new GeometryService('http://tasks.arcgisonline.com/ArcGIS/rest/services/Geometry/GeometryServer');

    //image parameters for dynamic services, set to png32 for higher quality exports.
    var imageParameters = new ImageParameters();
    imageParameters.format = 'png32';

    return {
        // used for debugging your app
        isDebug: true,
        //default mapClick mode, mapClickMode lets widgets know what mode the map is in to avoid multipult map click actions from taking place (ie identify while drawing).
        defaultMapClickMode: 'identify',
        // map options, passed to map constructor. see: https://developers.arcgis.com/javascript/jsapi/map-amd.html#map1
        mapOptions: {
            basemap: 'streets',
            center: [-10800531.491742816,-10860496.340432458],
            zoom: 12,
            sliderStyle: 'small'
        },
        panes: {
            left: {
                splitter: true
            },
            // 	right: {
            // 		id: 'sidebarRight',
            // 		placeAt: 'outer',
            // 		region: 'right',
            // 		splitter: true,
            // 		collapsible: true
            // 	},
            bottom: {
                id: 'sidebarBottom',
                placeAt: 'outer',
                splitter: true,
                collapsible: true,
                region: 'bottom',
                style: 'height:300px;',
                content: '<div id="relatedRecords" style="height:100%;"></div>'
            },
            // 	top: {
            // 		id: 'sidebarTop',
            // 		placeAt: 'outer',
            // 		collapsible: true,
            // 		splitter: true,
            // 		region: 'top'
            // 	}
        },
         collapseButtonsPane: 'center', //center or outer

        // operationalLayers: Array of Layers to load on top of the basemap: valid 'type' options: 'dynamic', 'tiled', 'feature'.
        // The 'options' object is passed as the layers options for constructor. Title will be used in the legend only. id's must be unique and have no spaces.
        // 3 'mode' options: MODE_SNAPSHOT = 0, MODE_ONDEMAND = 1, MODE_SELECTION = 2
        operationalLayers: [{
                type: 'feature',
                url: 'http://sampleserver3.arcgisonline.com/ArcGIS/rest/services/Petroleum/KSPetro/MapServer/0',
                title: 'STLJS Meetup Home Towns',
                options: {
                    id: 'meetupHometowns',
                    opacity: 1.0,
                    visible: true,
                    mode: 0
                },
                editorLayerInfos: {
                    disableGeometryUpdate: false
                },
                legendLayerInfos: {
                    exclude: false,
                    layerInfo: {
                        title: 'My layer'
                    }
                }
            }, {
                type: 'feature',
                url: 'http://sampleserver3.arcgisonline.com/ArcGIS/rest/services/SanFrancisco/311Incidents/FeatureServer/0',
                title: 'San Francisco 311 Incidents',
                options: {
                    id: 'sf311Incidents',
                    opacity: 1.0,
                    visible: true,
                    mode: 0
                }
            }, {
                type: 'feature',
                url: 'http://services.arcgis.com/V6ZHFr6zdgNZuVG0/ArcGIS/rest/services/Beverly%20Hills%20Trees%20By%20Block/FeatureServer/0',
                title: 'San Francisco 311 Incidents',
                options: {
                    id: 'asdfsaf',
                    opacity: 1.0,
                    visible: true,
                    mode: 0
                }
            }, {
                type: 'dynamic',
                url: 'http://sampleserver1.arcgisonline.com/ArcGIS/rest/services/PublicSafety/PublicSafetyOperationalLayers/MapServer',
                title: 'Louisville Public Safety',
                options: {
                    id: 'louisvillePubSafety',
                    opacity: 1.0,
                    visible: true,
                    imageParameters: imageParameters
                },
                identifyLayerInfos: {
                    layerIds: [2, 4, 5, 8, 12, 21]
                },
                legendLayerInfos: {
                    layerInfo: {
                        hideLayers: [21]
                    }
                }
            }, {
                type: 'dynamic',
                url: 'http://sampleserver6.arcgisonline.com/arcgis/rest/services/DamageAssessment/MapServer',
                title: 'Damage Assessment',
                options: {
                    id: 'DamageAssessment',
                    opacity: 1.0,
                    visible: true,
                    imageParameters: imageParameters
                },
                legendLayerInfos: {
                    exclude: true
                },
                layerControlLayerInfos: {
                    swipe: true,
                    metadataUrl: true,
                    expanded: true
                }
            }],
        // set include:true to load. For titlePane type set position the the desired order in the sidebar
        widgets: {
            
            identify: {
                include: true,
                id: 'identify',
                type: 'titlePane',
                path: 'gis/dijit/Identify',
                title: 'Identify',
                open: false,
                position: 3,
                options: 'config/identify'
            },
            settings: {
                include: true,
                id: 'settings',
                position: 10,
                type: 'titlePane',
                path: 'gis/CMV_Widgets/widgets/AppSettings',
                title: 'Save/Share Current Map',
                options: {
                    //these options are required:
                    map: true,
                    layerControlLayerInfos: true,
                    server: 'js/gis/CMV_Widgets/widgets/AppSettings/php/index.php'

                }
            },
            relatedRecords: {
                include: true,
                id: 'relatedRecords',
                type: 'domNode',
                srcNodeRef: 'relatedRecords',
                path: 'gis/CMV_Widgets/widgets/RelationshipTableTabs',
                title: 'Related Records',
                options: {
                    //required option
                    layerControlLayerInfos: true,
                    relationships: {
                        sf311Incidents: {
                            1: {
                                //don't show this one
                                exclude: true
                            }
                        }
                    }
                }
            }
        }
    };
});