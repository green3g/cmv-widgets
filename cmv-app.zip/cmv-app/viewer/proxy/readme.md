# AGS Proxy page help

For full info please read here:
[https://developers.arcgis.com/javascript/jshelp/ags_proxy.html](https://developers.arcgis.com/javascript/jshelp/ags_proxy.html)

You will more than likely need a proxy page for printing and other large cross domain requests.
There are diffrent flavors (.net, jsp, php) of the proxy page depending on your server side technology. See the above link for full details.